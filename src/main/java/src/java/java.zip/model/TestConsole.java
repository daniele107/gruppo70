
// File: TestConsole.java
package model;

public class TestConsole {
    public static void main(String[] args) {
        System.out.println("TestConsole avviato");
    }
}