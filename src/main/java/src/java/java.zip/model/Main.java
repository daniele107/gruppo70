// File: model/Main.java
package model;

import controller.Controller;
import gui.SignIn;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        // Carica stato (o ne crea uno nuovo)
        Controller ctrl = Controller.loadState();
        // Salva automaticamente a chiusura JVM
        Runtime.getRuntime().addShutdownHook(new Thread(ctrl::saveState));

        // Avvia la finestra di login invece della MainMenuGUI
        SwingUtilities.invokeLater(() -> new SignIn(ctrl));
    }
}
